import express from "express";
import multer from "multer";

import {
  createComplaint,
  getAllComplaints,
  getMyComplaints,
  updateComplaintStatus
} from "../controllers/complaintController.js";

import { protectRoute } from "../middleware/auth.js";

import Complaint from "../models/Complaint.js";

const router = express.Router();

/* -------- MULTER CONFIG -------- */

const upload = multer({
  dest: "uploads/"
});

/* -------- EXISTING ROUTES -------- */

// Create complaint
router.post(
  "/",
  protectRoute,
  createComplaint
);

// Get all complaints
router.get(
  "/",
  protectRoute,
  getAllComplaints
);

// Get my complaints
router.get(
  "/my",
  protectRoute,
  getMyComplaints
);

// Update status (existing)
router.put(
  "/:id",
  protectRoute,
  updateComplaintStatus
);

/* -------- NEW FEATURES -------- */

// 🔹 Assign complaint (Admin)
router.put("/assign/:id", protectRoute, async (req, res) => {
  try {
    const { assignedTo } = req.body;

    const complaint = await Complaint.findByIdAndUpdate(
      req.params.id,
      { assignedTo, status: "Assigned" },
      { new: true }
    );

    res.json(complaint);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 🔹 Vote system
router.post("/vote/:id", protectRoute, async (req, res) => {
  try {
    const complaint = await Complaint.findByIdAndUpdate(
      req.params.id,
      { $inc: { votes: 1 } },
      { new: true }
    );

    res.json(complaint);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
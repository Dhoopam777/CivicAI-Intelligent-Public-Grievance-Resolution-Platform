import cookieParser from "cookie-parser";
import cors from "cors";
import dotenv from "dotenv";
import express from "express";

import { connectDB } from "./config/db.js";
import complaintRouter from "./routes/complaintRoutes.js";
import userRouter from "./routes/userRoutes.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

/* ---------- MIDDLEWARE ---------- */

app.use(express.json());
app.use(cookieParser());
app.use(cors({
  origin: [
    "http://localhost:5173",
    "https://civic-ai-intelligent-public-grievance-resolution-platform.vercel.app"
  ],
  credentials: true
}));

/* ---------- STATIC FOLDER FOR MULTER ---------- */

app.use("/uploads", express.static("uploads"));

/* ---------- ROUTES ---------- */

app.get("/", (req, res) => {
  res.send("Server is running!");
});

app.use("/api/auth", userRouter);
app.use("/api/complaints", complaintRouter);

/* ---------- DATABASE ---------- */

await connectDB();

/* ---------- SERVER START ---------- */

app.listen(PORT, () => {
  console.log(`server is running on PORT: ${PORT}`);
});
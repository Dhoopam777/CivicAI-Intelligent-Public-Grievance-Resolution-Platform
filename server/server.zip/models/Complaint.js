import mongoose from "mongoose";

const complaintSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User"
    },

    city: {
      type: String,
      required: true
    },

    state: {
      type: String,
      required: true
    },

    address: {
      type: String,
      required: true
    },

    description: {
      type: String,
      required: true
    },

    category: {
      type: String,
      default: "General"
    },

    image: {
      type: String
    },

    imageUrl: {
      type: String
    },

    priority: {
      type: String,
      enum: ["Low", "Medium", "High"],
      default: "Low"
    },

    location: {
      lat: Number,
      lng: Number
    },

    assignedTo: {
      type: String,
      enum: ["BBMP", "Water Board", "Electricity", "Roads", "Other"],
      default: "BBMP"
    },

    status: {
      type: String,
      enum: ["Pending", "Forwarded", "Assigned", "In Progress", "Resolved"],
      default: "Pending"
    },

    votes: {
      type: Number,
      default: 0
    }
  },
  { timestamps: true }
);

const Complaint = mongoose.model("Complaint", complaintSchema);

export default Complaint;
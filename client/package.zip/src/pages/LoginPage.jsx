import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-hot-toast";
import { Toaster } from "react-hot-toast";
import ParticlesBackground from "../components/ParticlesBackground";
import Loader from "../components/Loader";

const LoginPage = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      setLoading(true);

      const res = await axios.post(
        // "https://civicai-intelligent-public-grievance.onrender.com/api/auth/login",
        "http://localhost:5000/api/auth/login",
        { email, password }
      );

      // ✅ store token
      localStorage.setItem("token", res.data.token);

      // ✅ set default header (IMPORTANT FIX)
      axios.defaults.headers.common["Authorization"] = res.data.token;

      toast.success("Login successful");

      navigate("/profile");

    } catch (err) {
      console.error(err);
      toast.error("Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <ParticlesBackground />

      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-950 via-purple-900 to-black">
        <div className="bg-white/10 backdrop-blur-md p-10 rounded-2xl shadow-2xl w-full max-w-md text-white shadow-[0_0_40px_rgba(99,102,241,0.3)]">

          <h1 className="text-3xl font-bold text-center mb-6">
            Login to CivicAI
          </h1>

          <form onSubmit={handleLogin} className="flex flex-col gap-4">

            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="p-3 rounded-lg bg-white/20 placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />

            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="p-3 rounded-lg bg-white/20 placeholder-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-400"
            />

            <button
              type="submit"
              disabled={loading}
              className="mt-2 p-3 bg-indigo-600 hover:bg-indigo-700 rounded-lg transition transform hover:scale-105 flex items-center justify-center"
            >
              {loading ? <Loader /> : "Login"}
            </button>

          </form>

          <div className="flex items-center my-6">
            <div className="flex-grow h-px bg-gray-400"></div>
            <span className="px-3 text-sm text-gray-300">or</span>
            <div className="flex-grow h-px bg-gray-400"></div>
          </div>

          <button className="w-full p-3 bg-white text-black rounded-lg hover:bg-gray-200 transition">
            Continue with Google
          </button>

          <p className="text-center text-sm mt-6 text-gray-300">
            Don't have an account?
            <span
              onClick={() => navigate("/register")}
              className="ml-2 text-indigo-400 cursor-pointer hover:underline"
            >
              Register
            </span>
          </p>

        </div>
      </div>
      <Toaster />
    </>
  );
};

export default LoginPage;
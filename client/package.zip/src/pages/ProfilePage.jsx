import axios from "axios";
import { useEffect, useState } from "react";
import { toast } from "react-hot-toast";
import ParticlesBackground from "../components/ParticlesBackground";

const ProfilePage = () => {
  const [city,setCity] = useState("");
  const [state,setState] = useState("");
  const [address,setAddress] = useState("");
  const [description,setDescription] = useState("");

  const [quickDesc,setQuickDesc] = useState("");
  const [image,setImage] = useState("");

  const [complaints,setComplaints] = useState([]);
  const [loading,setLoading] = useState(false);

  const token = localStorage.getItem("token");

  /* ---------- IMAGE ---------- */

  const handleImage = (file) => {
    if(!file) return;

    const reader = new FileReader();
    reader.readAsDataURL(file);

    reader.onloadend = ()=>{
      setImage(reader.result);
    };
  };

  /* ---------- MANUAL SUBMIT ---------- */

  const submitManualComplaint = async(e)=>{
    e.preventDefault();

    try{
      setLoading(true);

      await axios.post(
        // "https://civicai-intelligent-public-grievance.onrender.com/api/complaints",
        "http://localhost:5000/api/complaints",
        { city,state,address,description,image },
        {
          headers:{
           Authorization: `Bearer ${token}`,
            "Content-Type": "application/json"
          }
        }
      );

      toast.success("Complaint submitted successfully");

      setCity("");
      setState("");
      setAddress("");
      setDescription("");
      setImage("");

      fetchComplaints();

    }catch(err){
      console.error(err);
      toast.error("Submission failed");
    }finally{
      setLoading(false);
    }
  };

  /* ---------- QUICK LOCATION ---------- */

  const quickLocationSubmit = ()=>{

    if(!quickDesc){
      toast.error("Please describe the issue");
      return;
    }

    navigator.geolocation.getCurrentPosition(async(pos)=>{

      try{
        setLoading(true);

        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;

        const res = await axios.get(
          `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`
        );

        const addressData = res.data?.address || {};

        const detectedCity =
          addressData.city ||
          addressData.town ||
          addressData.village ||
          "";

        const detectedState = addressData.state || "";
        const detectedAddress = res.data?.display_name || "";

        await axios.post(
          // "https://civicai-intelligent-public-grievance.onrender.com/api/complaints",
          "http://localhost:5000/api/complaints",
          {
            city: detectedCity,
            state: detectedState,
            address: detectedAddress,
            description: quickDesc,
            image
          },
          {
            headers:{
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json"
            }
          }
        );

        toast.success("Complaint submitted using location");

        setQuickDesc("");
        setImage("");

        fetchComplaints();

      }catch(err){
        console.error(err);
        toast.error("Submission failed");
      }finally{
        setLoading(false);
      }

    });

  };

  /* ---------- FETCH ---------- */

  const fetchComplaints = async()=>{

    try{
      const res = await axios.get(
        // "https://civicai-intelligent-public-grievance.onrender.com/api/complaints/my",
        "http://localhost:5000/api/complaints",
        {
          headers:{
             Authorization: `Bearer ${token}`,
            "Content-Type": "application/json"
          }
        }
      );

      const list = Array.isArray(res.data) ? res.data : [];

      setComplaints(list);

    }catch(err){
      console.error(err);
      setComplaints([]);
    }

  };

  useEffect(()=>{
    fetchComplaints();
  },[]);

  /* ---------- UI ---------- */

  return(
    <>
      <ParticlesBackground/>

      <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-900 to-black text-white p-8">

        <h1 className="text-4xl font-bold text-center mb-10">
          Civic Complaint Portal
        </h1>

        {/* MANUAL FORM */}

        <div className="max-w-xl mx-auto bg-white/10 backdrop-blur-md p-8 rounded-xl shadow-xl mb-10">

          <h2 className="text-xl font-semibold mb-4 text-center">
            Manual Complaint Submission
          </h2>

          <form
            onSubmit={submitManualComplaint}
            className="flex flex-col gap-3"
          >

            <input
              placeholder="City"
              value={city}
              onChange={(e)=>setCity(e.target.value)}
              className="p-3 rounded-lg text-black"
            />

            <input
              placeholder="State"
              value={state}
              onChange={(e)=>setState(e.target.value)}
              className="p-3 rounded-lg text-black"
            />

            <input
              placeholder="Address"
              value={address}
              onChange={(e)=>setAddress(e.target.value)}
              className="p-3 rounded-lg text-black"
            />

            <textarea
              placeholder="Describe the issue"
              value={description}
              onChange={(e)=>setDescription(e.target.value)}
              className="p-3 rounded-lg text-black"
            />

            <input
              type="file"
              onChange={(e)=>handleImage(e.target.files[0])}
            />

            <button
              type="submit"
              disabled={loading}
              className="bg-indigo-600 hover:bg-indigo-700 p-3 rounded-lg"
            >
              {loading ? "Submitting..." : "Submit Complaint"}
            </button>

          </form>

        </div>

        {/* QUICK LOCATION */}

        <div className="max-w-xl mx-auto bg-white/10 backdrop-blur-md p-8 rounded-xl shadow-xl mb-10">

          <h2 className="text-xl font-semibold mb-4 text-center">
            Quick Report (Use My Location)
          </h2>

          <textarea
            placeholder="Describe the issue"
            value={quickDesc}
            onChange={(e)=>setQuickDesc(e.target.value)}
            className="p-3 rounded-lg text-black w-full mb-3"
          />

          <input
            type="file"
            onChange={(e)=>handleImage(e.target.files[0])}
            className="mb-4"
          />

          <button
            onClick={quickLocationSubmit}
            className="bg-green-600 hover:bg-green-700 p-3 rounded-lg w-full"
          >
            📍 Use My Location & Submit
          </button>

        </div>

        {/* COMPLAINT LIST */}

        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">

          {(Array.isArray(complaints) ? complaints : []).map((c)=>(
            <div
              key={c._id}
              className="bg-white/10 backdrop-blur-md p-6 rounded-xl shadow-lg hover:scale-105 transition"
            >

              <h3 className="font-bold mb-2">{c.category}</h3>

              <p>{c.description}</p>

              <p className="text-sm mt-2">
                <b>City:</b> {c.city}
              </p>

              <p className="text-sm">
                <b>Status:</b> {c.status}
              </p>

              {c.image && (
                <img
                  src={c.image}
                  className="mt-3 rounded-lg"
                  alt="complaint"
                />
              )}

            </div>
          ))}

        </div>

      </div>
    </>
  );
};

export default ProfilePage;
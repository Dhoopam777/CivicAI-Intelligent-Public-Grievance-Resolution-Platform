import axios from "axios";
import { useEffect, useState } from "react";
import { toast } from "react-hot-toast";
import ParticlesBackground from "../components/ParticlesBackground";

const AdminPage = () => {
  const [complaints, setComplaints] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const [selected, setSelected] = useState(null);

  const [category, setCategory] = useState("All");
  const [status, setStatus] = useState("All");
  const [priority, setPriority] = useState("All");
  const [search, setSearch] = useState("");

  const token = localStorage.getItem("token");

  /* ---------- FETCH ---------- */

  const fetchComplaints = async () => {
    try {
      const res = await axios.get(
        // "https://civicai-intelligent-public-grievance.onrender.com/api/complaints",
        "http://localhost:5000/api/complaints",
        { headers: { Authorization: `Bearer ${token}`, } }
      );

      setComplaints(Array.isArray(res.data) ? res.data : []);
      setFiltered(Array.isArray(res.data) ? res.data : []);
    } catch (err) {
      toast.error("Failed to load complaints");
    }
  };

  useEffect(() => {
    fetchComplaints();
  }, []);

  /* ---------- FILTER ---------- */

  useEffect(() => {
    let data = [...complaints];

    if (category !== "All") {
      data = data.filter((c) => c.category === category);
    }

    if (status !== "All") {
      data = data.filter((c) => c.status === status);
    }

    if (priority !== "All") {
      data = data.filter((c) => c.priority === priority);
    }

    if (search !== "") {
      data = data.filter(
        (c) =>
          c.city.toLowerCase().includes(search.toLowerCase()) ||
          c.description.toLowerCase().includes(search.toLowerCase())
      );
    }

    setFiltered(data);
  }, [category, status, priority, search, complaints]);

  /* ---------- STATUS UPDATE ---------- */

  const updateStatus = async (id, status) => {
    try {
      await axios.put(
        // `https://civicai-intelligent-public-grievance.onrender.com/api/complaints/${id}`,
        `http://localhost:5000/api/complaints/${id}`,
        { status },
        { headers: { Authorization: `Bearer ${token}`, } }
      );

      toast.success("Status updated");
      fetchComplaints();
    } catch {
      toast.error("Failed to update");
    }
  };

  /* ---------- ASSIGN ---------- */

  const assignDept = async (id, dept) => {
    try {
      await axios.put(
        // `https://civicai-intelligent-public-grievance.onrender.com/api/complaints/assign/${id}`,
        `http://localhost:5000/api/complaints/assign/${id}`,
        { assignedTo: dept },
        { headers: { Authorization: `Bearer ${token}`, } }
      );

      toast.success("Assigned successfully");
      fetchComplaints();
    } catch {
      toast.error("Assign failed");
    }
  };

  /* ---------- UI HELPERS ---------- */

  const badgeColor = (status) => {
    if (status === "Resolved") return "bg-green-500";
    if (status === "In Progress") return "bg-yellow-500";
    if (status === "Assigned") return "bg-blue-500";
    return "bg-red-500";
  };

  const openMap = (c) => {
    if (!c.location) return;
    const url = `https://www.google.com/maps?q=${c.location.lat},${c.location.lng}`;
    window.open(url, "_blank");
  };

  return (
    <>
      <ParticlesBackground />

      <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-900 to-black text-white p-8">
        <h1 className="text-4xl font-bold text-center mb-8">
          🏛 Civic Admin Dashboard
        </h1>

        {/* FILTERS */}

        <div className="flex flex-wrap gap-4 justify-center mb-8">
          <input
            placeholder="Search complaints..."
            onChange={(e) => setSearch(e.target.value)}
            className="px-4 py-2 rounded-lg text-black"
          />

          <select onChange={(e) => setCategory(e.target.value)} className="px-4 py-2 rounded-lg text-black">
            <option value="All">All Categories</option>
            <option value="Road Issue">Road Issue</option>
            <option value="Sanitation">Sanitation</option>
            <option value="Water Supply">Water</option>
            <option value="Electricity">Electricity</option>
          </select>

          <select onChange={(e) => setStatus(e.target.value)} className="px-4 py-2 rounded-lg text-black">
            <option value="All">All Status</option>
            <option value="Pending">Pending</option>
            <option value="Assigned">Assigned</option>
            <option value="In Progress">In Progress</option>
            <option value="Resolved">Resolved</option>
          </select>

          <select onChange={(e) => setPriority(e.target.value)} className="px-4 py-2 rounded-lg text-black">
            <option value="All">All Priority</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>

        {/* TABLE */}

        <div className="overflow-x-auto bg-white text-black rounded-xl shadow-lg">
          <table className="w-full">
            <thead className="bg-black text-white">
              <tr>
                <th className="p-3">City</th>
                <th className="p-3">Category</th>
                <th className="p-3">Priority</th>
                <th className="p-3">Status</th>
                <th className="p-3">Assign</th>
                <th className="p-3">Image</th>
                <th className="p-3">Actions</th>
              </tr>
            </thead>

            <tbody>
              {filtered.map((c) => (
                <tr key={c._id} className="text-center border-b hover:bg-gray-100">

                  <td className="p-3">{c.city}</td>
                  <td className="p-3">{c.category}</td>
                  <td className="p-3">{c.priority}</td>

                  <td className="p-3">
                    <span className={`text-white px-3 py-1 rounded-full text-sm ${badgeColor(c.status)}`}>
                      {c.status}
                    </span>
                  </td>

                  {/* 🔥 ASSIGN DROPDOWN */}
                  <td className="p-3">
                    <select
                      value={c.assignedTo}
                      onChange={(e) => assignDept(c._id, e.target.value)}
                      className="px-2 py-1 rounded"
                    >
                      <option>BBMP</option>
                      <option>Water Board</option>
                      <option>Electricity</option>
                      <option>Roads</option>
                    </select>
                  </td>

                  <td className="p-3">
                    {c.image && (
                      <button
                        onClick={() => setSelected(c)}
                        className="bg-indigo-600 text-white px-3 py-1 rounded"
                      >
                        View
                      </button>
                    )}
                  </td>

                  <td className="p-3 flex justify-center gap-2">
                    <button
                      onClick={() => updateStatus(c._id, "In Progress")}
                      className="bg-yellow-500 px-3 py-1 rounded text-white"
                    >
                      Start
                    </button>

                    <button
                      onClick={() => updateStatus(c._id, "Resolved")}
                      className="bg-green-500 px-3 py-1 rounded text-white"
                    >
                      Resolve
                    </button>
                  </td>

                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* MODAL */}

        {selected && (
          <div className="fixed inset-0 bg-black/80 flex items-center justify-center">
            <div className="bg-slate-900 text-white p-6 rounded-xl max-w-lg w-full">
              <h2 className="text-2xl font-bold mb-4">Complaint Details</h2>

              <p><b>City:</b> {selected.city}</p>
              <p><b>Address:</b> {selected.address}</p>
              <p><b>Status:</b> {selected.status}</p>
              <p><b>Assigned To:</b> {selected.assignedTo}</p>

              <p className="mt-2"><b>Description:</b> {selected.description}</p>

              {selected.image && (
                <img src={selected.image} className="mt-4 rounded-lg" />
              )}

              <div className="flex justify-between mt-6">
                <button onClick={() => openMap(selected)} className="bg-blue-600 px-4 py-2 rounded">
                  Map
                </button>

                <button onClick={() => setSelected(null)} className="bg-red-500 px-4 py-2 rounded">
                  Close
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </>
  );
};

export default AdminPage;